<?php 
header('Location: public/');
