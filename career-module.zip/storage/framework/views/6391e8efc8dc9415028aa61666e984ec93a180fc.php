    <div class="banner banner-dm">
        <h1 class="title">
            Digital Marketing <br>
            Specialist 101
        </h1>
    </div>
    <p class="sp mt-md-5 text-center px-5">
        This module consists of all the <b>background information</b> on <b> Digital Marketing Specialist</b> as a
        career, 2 (two) <b>case
            studies</b> and a final reflection. Complete all sections <b>in order</b> . Refer to Glossary and
        Additional
        Resources when
        necessary.
        <br><br>
        Happy learning!
    </p>
<?php /**PATH /home/u5332263/public_html/others/github/career-module/resources/views/modules/digital-marketing/banner.blade.php ENDPATH**/ ?>