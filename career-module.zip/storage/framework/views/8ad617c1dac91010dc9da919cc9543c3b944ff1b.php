<?php $__env->startSection('content'); ?>
<div class="accordion accordion-flush" id="p0">
    <div class="accordion-item">
        <h2 class="section-header" id="p0-header">
            <div>Introduction</div>
        </h2>
    </div>

    <div class="accordion-item">
        <h2 class="accordion-header" id="p0-1">
            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#c-p0-1"
                aria-expanded="false" aria-controls="c-p0-1">
                Video Intro
            </button>
        </h2>

        <div id="c-p0-1" class="accordion-collapse collapse show" aria-labelledby="p0-1" data-bs-parent="#p0">
            <div class="accordion-body">
                <h2>VIDEO 1 - TRAILER</h2>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('modules.data-scientist-part.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5332263/public_html/others/github/career-module/resources/views/modules/data-scientist-part/part-0.blade.php ENDPATH**/ ?>