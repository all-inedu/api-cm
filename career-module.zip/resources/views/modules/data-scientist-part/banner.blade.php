<div class="banner banner-ds">
    <h1 class="title">
        Data Scientist <br>
        101
    </h1>
</div>
<p class="sp mt-md-5 text-center px-5">
    This module consists of all the <b>background information</b> on <b>Data Scientist</b> as a career, 2 (two)
    <b>case
        studies</b> and a
    final <b>reflection</b>. Complete all sections <b>in order</b>. Refer to Glossary and Additional Resources when
    necessary
    <br><br>
    Happy learning!
</p>
